Here's the code at the end of JavaScript Course Lesson 13 (if you need it).
## Steps
1. Click Code > Download ZIP <br>
   <img width="485" alt="Screenshot 2023-07-27 at 11 25 55 AM" src="https://github.com/SuperSimpleDev/javascript-lesson-14-starting-code/assets/70604577/610f8222-1508-46a2-84ec-cc7f7a56fd0d">
2. Open the downloaded file (this will unzip it)
3. Optional: move the folder to another place on your computer, rename the folder

That's it! Now you're ready to follow along.
